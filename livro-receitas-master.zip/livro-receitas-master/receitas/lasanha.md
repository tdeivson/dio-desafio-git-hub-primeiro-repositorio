# Lasanha de Queijo :  :cheese: :rat:

##  **Ingredientes:**

- 1 pacote de lasanha
- Queijos mussarela e prato
- 2 dentes de alho
- Cebola a gosto
- 1 litro de leite
- Sal a gosto
- 3 colheres de maisena
- 1 colher (sopa) bem cheia de manteiga
- 1 caixinha de creme de leite
- Cheiro verde a gosto
- Orégano a gosto



##  MODO DE PREPARO

1. **Molho:**
2. Em um panela coloque a manteiga e frite o alho e a cebola.
3. Em seguida acrescente o leite, a maisena e o sal.
4. Mexa até formar um creme.
5. Desligue o fogo e acrescente o cheiro verde e o creme de leite.
6. **Como montar a lasanha:**
7. Em uma assadeira ou em um pirex faça uma camada de molho, em seguida coloque uma camada da massa da lasanha e em seguida coloque o queijo.
8. Em cima do queijo jogue um pouco de orégano para dar um gostinho especial.
9. Em seguida coloque molho novamente, outra camada de massa de lasanha e queijo e orégano novamente, faça mais uma camada (molho, massa, queijo) e por cima do queijo jogue um pouco mais de molho.
10. Se preferir mais molhadinha jogue todo o molho restante, caso não prefira assim, jogue o molho até que cubra o queijo.
11. Leve ao forno por 35 minutos aproximadamente.